<?php
    print time();
?>